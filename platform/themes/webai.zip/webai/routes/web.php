<?php

use Botble\Theme\Facades\Theme;
use Botble\AiVideoGenerator\Http\Controllers\Fronts\CreditPackagePurchaseController;
use Botble\AiVideoGenerator\Http\Controllers\Fronts\VideoLabController;
use Botble\AiVideoGenerator\Models\AiContentPost;
use Illuminate\Support\Facades\Route;

Theme::registerRoutes(function (): void {
    Route::get('image-studio', fn () => Theme::scope('image')->render())->name('public.studio-image');
    Route::get('video-lab', [VideoLabController::class, 'index'])->name('public.video-lab');
    Route::post('video-lab/media', [VideoLabController::class, 'uploadMedia'])->name('public.video-lab.media');
    Route::post('video-lab/generate', [VideoLabController::class, 'generate'])->name('public.video-lab.generate');
    Route::get('video-lab/tasks/{taskId}', [VideoLabController::class, 'status'])->name('public.video-lab.task-status');
    Route::get('credit-packages', [CreditPackagePurchaseController::class, 'index'])->name('public.credit-packages.index');
    Route::post('credit-package-purchases', [CreditPackagePurchaseController::class, 'start'])->name('public.credit-package-purchases.start');
    Route::get('credit-package-purchases/{payment:charge_id}/status', [CreditPackagePurchaseController::class, 'status'])->name('public.credit-package-purchases.status');
    Route::get('credit-package-purchases/{payment:charge_id}', [CreditPackagePurchaseController::class, 'payment'])->name('public.credit-package-purchases.payment');
    Route::redirect('top-up-credit', 'credit-packages')->name('public.top-up-credit');
});

Theme::routes();

Theme::registerRoutes(function (): void {
    Route::get('/', function () {
        $homePost = AiContentPost::query()
            ->where('status', true)
            ->where('display_location', 'home')
            ->latest('id')
            ->first();

        $introModalPost = AiContentPost::query()
            ->where('status', true)
            ->where('display_location', 'intro_modal')
            ->latest('id')
            ->first();

        return Theme::scope('home', compact('homePost', 'introModalPost'))->render();
    })->name('public.home');
});
