@php
    $customer = auth('customer')->check() ? auth('customer')->user() : null;
    $adminUser = auth()->check() ? auth()->user() : null;
    $user = $customer ?: $adminUser;
    $isLoggedIn = (bool) $user;
    $email = $user->email ?? $user->phone ?? '';
    $creditBalance = (int) ($customer?->credits_balance ?? 0);
    $loginUrl = \Illuminate\Support\Facades\Route::has('ai-video-generator.login')
        ? route('ai-video-generator.login')
        : (\Illuminate\Support\Facades\Route::has('customer.login') ? route('customer.login') : url('login'));
    $registerUrl = \Illuminate\Support\Facades\Route::has('ai-video-generator.register')
        ? route('ai-video-generator.register')
        : (\Illuminate\Support\Facades\Route::has('customer.register') ? route('customer.register') : url('register'));
    $logoutUrl = \Illuminate\Support\Facades\Route::has('ai-video-generator.logout')
        ? route('ai-video-generator.logout')
        : (\Illuminate\Support\Facades\Route::has('customer.logout') ? route('customer.logout') : null);
    $sidebarMenu = Menu::renderMenuLocation('main-menu', ['view' => 'sidebar-menu']);
    $logo = Theme::getLogoImage(['class' => 'webai-brand-logo'], maxHeight: 48);
@endphp

<aside class="webai-sidebar" id="webai-sidebar">
    <a class="webai-brand" href="{{ route('public.home') }}" aria-label="WebAI">
        @if ($logo)
            {{ $logo }}
        @else
            <span class="webai-brand-mark">S</span>
            <span class="webai-brand-text">Solan<span>AI</span></span>
        @endif
    </a>

    <nav class="webai-nav" aria-label="Main navigation">
        {!! $sidebarMenu !!}
    </nav>

    @if ($isLoggedIn)
    <div class="webai-user" data-webai-user-menu role="button" tabindex="0" aria-expanded="false">
        <div class="webai-avatar">○</div>
        <div>
            <div class="webai-credit" data-webai-credit-balance>Credits: {{ number_format($creditBalance, 0, ',', '.') }}</div>
            <div class="webai-email">{{ $email }}</div>
        </div>
        @if ($logoutUrl)
            <a class="webai-logout" href="{{ $logoutUrl }}">Đăng xuất</a>
        @endif
    </div>
    @else
    <div class="webai-auth-actions">
        <a class="webai-auth-action webai-auth-action--login" href="{{ $loginUrl }}">Đăng nhập</a>
        <a class="webai-auth-action webai-auth-action--register" href="{{ $registerUrl }}">Đăng ký</a>
    </div>
    @endif
</aside>
