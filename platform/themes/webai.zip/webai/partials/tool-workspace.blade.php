@php
    $type ??= 'image';
    $title ??= 'Studio ảnh';
    $subtitle ??= 'Tạo nội dung sáng tạo bằng AI từ mô tả của bạn.';
    $recentTitle ??= 'Ảnh gần đây';
    $emptyText ??= 'Chưa có nội dung nào. Hãy thử tạo nội dung đầu tiên!';
    $placeholder ??= 'Mô tả chi tiết nội dung bạn muốn tạo...';
    $badge ??= strtoupper($type);
    $model ??= $type === 'video' ? 'Seedance 2.0 - Mini' : 'Flux Kontext - Pro';
    $models ??= [];
    $modelFields ??= $models[0]['fields'] ?? [];
    $requiredFields ??= $models[0]['required_fields'] ?? [];
    $durationOptions ??= $models[0]['durations'] ?? [];
    $qualityOptions ??= $models[0]['qualities'] ?? [];
    $aspectRatioOptions ??= $models[0]['aspect_ratios'] ?? [];
    $characterOrientationOptions ??= $models[0]['character_orientations'] ?? [];
    $shotTypeOptions ??= $models[0]['shot_types'] ?? [];
    $initialPrice = (float) ($models[0]['price'] ?? 0);
    $initialDuration = (float) ($models[0]['defaults']['duration'] ?? $durationOptions[0]['value'] ?? 1);
    $cost ??= $type === 'video' ? $initialPrice * $initialDuration : 4;
    $displayCost = rtrim(rtrim(number_format((float) $cost, 4, '.', ''), '0'), '.');
    $submitLabel ??= $type === 'video' ? 'Tạo video' : 'Tạo ảnh';
    $recentTasks ??= collect();
    $showVideoDemoHistory = $type === 'video' && $recentTasks->isEmpty();
@endphp

<div class="webai-tool-page @if ($type === 'video') webai-video-tool-page @endif">
<h1 class="webai-title">{{ $title }}</h1>

<p class="webai-subtitle">
    {{ $subtitle }}
</p>

<section class="webai-generation-panel" data-webai-generation-panel hidden>
    <h2 class="webai-section-title"><span>*</span> Video m&#7899;i t&#7841;o</h2>
    <div class="webai-generation-list" data-webai-generation-list></div>
</section>

<h2 class="webai-section-title"><span>✧</span> {{ $recentTitle }}</h2>

<section class="webai-empty @if ($recentTasks->isNotEmpty() || $showVideoDemoHistory) has-items @endif" aria-label="{{ $recentTitle }}" data-webai-recent-panel>
    <div class="webai-recent-list" data-webai-recent-list>
        @if ($showVideoDemoHistory)
            {{-- Temporary layout samples. They disappear as soon as real video history exists. --}}
            <article class="webai-generation-card is-loading webai-demo-video-item" aria-label="Video is being generated">
                <p class="webai-generation-status">&#272;ang t&#7841;o video</p>
                <div class="webai-generation-media"></div>
            </article>

            @for ($index = 1; $index <= 20; $index++)
                @php
                    $isPortraitSample = in_array($index, [2, 6, 9, 13, 17], true);
                @endphp
                <div class="webai-recent-item webai-demo-video-item @if ($isPortraitSample) webai-demo-video-item--portrait @endif" aria-label="Video sample">
                    <img src="https://picsum.photos/seed/webai-video-history-{{ $index }}/{{ $isPortraitSample ? '540/960' : '960/540' }}" alt="Video sample">
                </div>
            @endfor
        @endif

        @foreach ($recentTasks as $task)
            @php
                $generated = array_values(array_filter($task->generated ?? []));
                $firstMedia = $generated[0] ?? null;
                $isVideo = $firstMedia && preg_match('/\.(mp4|mov|webm)(\?.*)?$/i', $firstMedia);
            @endphp

            @if ($firstMedia)
                <div
                    class="webai-recent-item"
                    data-webai-generated='@json($generated)'
                    data-webai-title="Video {{ $task->task_id }}"
                >
                    @if ($isVideo)
                        <video src="{{ $firstMedia }}" controls playsinline preload="metadata"></video>
                    @else
                        <img src="{{ $firstMedia }}" alt="Video {{ $task->task_id }}">
                    @endif
                </div>
            @endif
        @endforeach
    </div>
    <p data-webai-recent-empty>{{ $emptyText }}</p>
</section>

<form class="webai-composer" action="{{ route('public.video-lab.generate') }}" method="post" data-webai-media-upload-url="{{ route('public.video-lab.media') }}" data-webai-task-status-url="{{ route('public.video-lab.task-status', ['taskId' => '__TASK_ID__']) }}">
    @csrf

    <textarea class="webai-prompt" name="prompt" placeholder="{{ $placeholder }}"></textarea>

    @if ($type === 'video')
        @php
            $mediaFields = [
                'image' => ['label' => 'Ảnh đầu', 'accept' => 'image/*'],
                'image_end' => ['label' => 'Ảnh cuối', 'accept' => 'image/*'],
                'image_url' => ['label' => 'Ảnh', 'accept' => 'image/*'],
                'video_url' => ['label' => 'Video', 'accept' => 'video/*'],
                'start_image_url' => ['label' => 'Ảnh đầu', 'accept' => 'image/*'],
                'end_image_url' => ['label' => 'Ảnh cuối', 'accept' => 'image/*'],
            ];
            $hasVisibleMediaFields = ! empty(array_intersect(array_keys($mediaFields), $modelFields));
        @endphp

        <div class="webai-media-fields" data-webai-media-fields @if (! $hasVisibleMediaFields) hidden @endif>
            @foreach ($mediaFields as $fieldName => $field)
                @php
                    $isVisible = in_array($fieldName, $modelFields, true);
                    $isRequired = in_array($fieldName, $requiredFields, true);
                @endphp

                <label class="webai-media-field" data-webai-media-field="{{ $fieldName }}" @if (! $isVisible) hidden @endif>
                    <span>{{ $field['label'] }} <strong @if (! $isRequired) hidden @endif>*</strong></span>
                    <input type="hidden" name="{{ $fieldName }}" data-webai-media-url @if ($isRequired) required @endif>
                    <input type="file" data-webai-media-file accept="{{ $field['accept'] }}" hidden>
                    <button class="webai-media-pick" type="button" data-webai-media-pick @if (str_starts_with($field['accept'], 'image/')) data-webai-tooltip="Dung l&#432;&#7907;ng &#7843;nh kh&#244;ng v&#432;&#7907;t qu&#225; 10MB. K&#237;ch th&#432;&#7899;c t&#7889;i thi&#7875;u 300x300px. T&#7881; l&#7879; &#7843;nh n&#234;n trong kho&#7843;ng 1:2.5 &#273;&#7871;n 2.5:1." @endif>{{ $isVisible ? 'Thêm' : 'Chọn' }}</button>
                    <em data-webai-media-preview>Chưa chọn</em>
                    @if (str_starts_with($field['accept'], 'image/'))
                        <img class="webai-media-image-preview" data-webai-image-preview alt="Ảnh đã chọn" hidden>
                    @endif
                    <button class="webai-media-clear" type="button" data-webai-media-clear aria-label="Xóa" hidden>×</button>
                    @if (false && $fieldName === 'video_url')
                        <small class="webai-media-note">Video phải có URL công khai. Thời lượng: 3–30 giây. Định dạng hỗ trợ: MP4, MOV, WEBM, M4V.</small>
                    @endif
                </label>
            @endforeach
        </div>
    @endif

    @php
        $initialModelLabel = ! empty($models) ? ($models[0]['label'] ?? 'Chọn model') : 'Chọn model';
    @endphp

    <div class="webai-toolbar">
        <button class="webai-filter-toggle" type="button" aria-label="Chọn model và tuỳ chọn" aria-expanded="false" data-webai-filter-toggle>
            <span class="webai-filter-toggle__label" data-webai-mobile-model-label>{{ $initialModelLabel }}</span>
        </button>

        <div class="webai-filter-panel" data-webai-filter-panel>
        @if (! empty($models))
            @php
                $modelsByParent = collect($models)->groupBy(fn ($modelOption) => $modelOption['parent'] ?? 'Model AI');
                $selectedModel = $models[0];
            @endphp
            <div class="webai-model-picker" data-webai-model-picker>
                <select class="webai-model-select" name="model" aria-label="Model AI" data-webai-model-native-select>
                    @foreach ($modelsByParent as $parent => $parentModels)
                        <optgroup label="{{ $parent }}">
                            @foreach ($parentModels as $modelOption)
                                <option value="{{ $modelOption['name'] }}" data-parent="{{ $parent }}" data-label="{{ $modelOption['label'] }}" data-price="{{ $modelOption['price'] ?? 0 }}" data-fields='@json($modelOption['fields'] ?? [])' data-required-fields='@json($modelOption['required_fields'] ?? [])' data-durations='@json($modelOption['durations'] ?? [])' data-qualities='@json($modelOption['qualities'] ?? [])' data-aspect-ratios='@json($modelOption['aspect_ratios'] ?? [])' data-character-orientations='@json($modelOption['character_orientations'] ?? [])' data-shot-types='@json($modelOption['shot_types'] ?? [])'>{{ $modelOption['label'] }}</option>
                            @endforeach
                        </optgroup>
                    @endforeach
                </select>
                <button class="webai-model-picker__trigger" type="button" aria-expanded="false" data-webai-model-picker-toggle>
                    <span data-webai-model-picker-parent>{{ $selectedModel['parent'] ?? 'Model AI' }}</span>
                    <strong data-webai-model-picker-label>{{ $selectedModel['label'] }}</strong>
                </button>
                <div class="webai-model-picker__menu" hidden data-webai-model-picker-menu>
                    @foreach ($modelsByParent as $parent => $parentModels)
                        <div class="webai-model-picker__group">
                            <span>{{ $parent }}</span>
                            @foreach ($parentModels as $modelOption)
                                <button type="button" data-webai-model-value="{{ $modelOption['name'] }}">{{ $modelOption['label'] }}</button>
                            @endforeach
                        </div>
                    @endforeach
                </div>
            </div>
        @else
            <div class="webai-pill">{{ $badge }} <strong>{{ $model }}</strong></div>
        @endif

        <select class="webai-select" name="aspect_ratio" aria-label="Tỷ lệ" data-webai-aspect-ratio-select @if (empty($aspectRatioOptions)) hidden @endif>
            @forelse ($aspectRatioOptions as $aspectRatioOption)
                <option value="{{ $aspectRatioOption['value'] }}">{{ $aspectRatioOption['label'] }}</option>
            @empty
            @endforelse
        </select>

        @if ($type === 'video')
            <select class="webai-select" name="quality" aria-label="Chất lượng" data-webai-quality-select @if (empty($qualityOptions)) hidden @endif>
                @forelse ($qualityOptions as $qualityOption)
                    <option value="{{ $qualityOption['value'] }}">{{ $qualityOption['label'] }}</option>
                @empty
                @endforelse
            </select>

            <select class="webai-select" name="duration" aria-label="Thời lượng" data-webai-duration-select @if (empty($durationOptions)) hidden @endif>
                @forelse ($durationOptions as $durationOption)
                    <option value="{{ $durationOption['value'] }}">{{ $durationOption['label'] }}</option>
                @empty
                    <option value="5">5s</option>
                    <option value="10">10s</option>
                @endforelse
            </select>

            <select class="webai-select" name="character_orientation" aria-label="Hướng nhân vật" data-webai-character-orientation-select @if (empty($characterOrientationOptions)) hidden @endif>
                @forelse ($characterOrientationOptions as $characterOrientationOption)
                    <option value="{{ $characterOrientationOption['value'] }}">{{ $characterOrientationOption['label'] }}</option>
                @empty
                @endforelse
            </select>

            <select class="webai-select" name="shot_type" aria-label="Shot type" data-webai-shot-type-select @if (empty($shotTypeOptions)) hidden @endif>
                @forelse ($shotTypeOptions as $shotTypeOption)
                    <option value="{{ $shotTypeOption['value'] }}">{{ $shotTypeOption['label'] }}</option>
                @empty
                @endforelse
            </select>
        @else
            <select class="webai-select" name="style" aria-label="Phong cách">
                <option>Realistic</option>
                <option>Concept art</option>
                <option>Anime</option>
            </select>
        @endif

        </div>

        <span class="webai-spacer"></span>
        <span class="webai-cost" data-webai-cost>{{ $displayCost }}</span>
        <button class="webai-send" type="submit" aria-label="{{ $submitLabel }}">↑</button>
    </div>
</form>
</div>
