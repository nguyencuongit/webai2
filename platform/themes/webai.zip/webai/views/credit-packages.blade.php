@php
    Theme::set('pageTitle', "Mua Credit");
@endphp

<section class="webai-credit-page">
    <header class="webai-credit-header">
        <h1>Mua Credit</h1>
        <p>Chọn gói Credit để tiếp tục tạo ảnh, video và giọng nói AI.</p>
        <strong>Lưu ý: Hạn sử dụng credits 3 tháng kể từ ngày mua.</strong>
    </header>

    <div class="webai-pricing-grid">
        @forelse ($creditPackages as $package)
            <article class="webai-pricing-card">
                <h2>{{ $package->name }}</h2>
                <p>Mã gói: {{ $package->code }}</p>

                <div class="webai-price">{{ number_format($package->price, 0, ',', '.') }} đ</div>
                <div class="webai-credit-amount">{{ number_format($package->credits, 0, ',', '.') }} Credits</div>

                @if ($customer)
                    <form method="post" action="{{ route('public.credit-package-purchases.start') }}">
                        @csrf
                        <input type="hidden" name="package_id" value="{{ $package->getKey() }}">
                        <button class="webai-buy-button" type="submit">Mua ngay</button>
                    </form>
                @else
                    <a class="webai-buy-button" href="{{ route('ai-video-generator.login', ['redirect' => url()->current()]) }}">Mua ngay</a>
                @endif
            </article>
        @empty
            <p class="webai-credit-empty">Chưa có gói Credit nào.</p>
        @endforelse
    </div>
</section>
